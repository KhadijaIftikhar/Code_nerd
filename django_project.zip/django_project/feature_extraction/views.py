from django.shortcuts import render
from django.http import HttpResponse
import logging as log
# start project libs
from sklearn.model_selection import train_test_split 
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import matplotlib as mpl
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from sklearn.feature_extraction.text import TfidfTransformer 
from sklearn.pipeline import Pipeline
import pandas as pd
import numpy as np
from mysql.connector import Error
import mysql.connector
from Bio import SeqIO
import re
import os
import random 
# end project libs

# BM Algo
def generateBadCharShift(term):
    skipList = {}
    for i in range(0, len(term)-1):
        skipList[term[i]] = len(term)-i-1
    return skipList

# Generate the Good Suffix Skip List
def findSuffixPosition(badchar, suffix, full_term):
    for offset in range(1, len(full_term)+1)[::-1]:
        flag = True
        for suffix_index in range(0, len(suffix)):
            term_index = offset-len(suffix)-1+suffix_index
            if term_index < 0 or suffix[suffix_index] == full_term[term_index]:
                pass
            else:
                flag = False
        term_index = offset-len(suffix)-1
        if flag and (term_index <= 0 or full_term[term_index-1] != badchar):
            return len(full_term)-offset+1

def generateSuffixShift(key):
    skipList = {}
    buffer = ""
    for i in range(0, len(key)):
        skipList[len(buffer)] = findSuffixPosition(key[len(key)-1-i], buffer, key)
        buffer = key[len(key)-1-i] + buffer
    return skipList
# Actual Search Algorithm
def BMSearch(haystack, needle):
    goodSuffix = generateSuffixShift(needle)
    badChar = generateBadCharShift(needle)
    i = 0
    while i < len(haystack)-len(needle)+1:
        j = len(needle)
        while j > 0 and needle[j-1] == haystack[i+j-1]:
            j -= 1
        if j > 0:
            badCharShift = badChar.get(haystack[i+j-1], len(needle))
            goodSuffixShift = goodSuffix[len(needle)-j]
            if badCharShift > goodSuffixShift:
                i += badCharShift
            else:
                i += goodSuffixShift
        else:
            return i
    return -1
# Imaginary function to handle an uploaded file.
def handle_uploaded_file(f,p,n):
    with open(p+n, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)

def dataAnalysis(input_file, output_file):
    # # reading csv file
    # data=pd.read_csv(input_file)
    # # spliting data
    # X = data['Sequence'].values
    # y = data['ID'].values

    # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

    # #Use pipeline to carry out steps in sequence with a single object
    # #SVM's rbf kernel gives highest accuracy in this classification problem.
    # text_clf = Pipeline([('vect', CountVectorizer()), ('tfidf', TfidfTransformer()), ('clf', SVC(kernel='linear', probability=True, random_state=1000,verbose=True))])

    # # fit model
    # text_clf.fit(X_train, y_train)

    #     # generate predictions
    # y_pred = text_clf.predict(X_test)

    # # calculate accuracy
    # accuracy = accuracy_score(y_test, y_pred)
    # print('Model accuracy is: {:.4f}'.format(accuracy))

    #     # predict probabilities for X_test using predict_proba
    # probabilities = text_clf.predict_proba(X_test)

    # # select the probabilities for label 1.0
    # y_proba = probabilities[:, 1]

    # # calculate false positive rate and true positive rate at different thresholds
    # false_positive_rate, true_positive_rate, thresholds = roc_curve(y_test, y_proba, pos_label=1)

    # # calculate AUC
    # roc_auc = auc(false_positive_rate, true_positive_rate)

    # plt.title('Receiver Operating Characteristic')
    # # plot the false positive rate on the x axis and the true positive rate on the y axis
    # roc_plot = plt.plot(false_positive_rate,
    #                     true_positive_rate,
    #                     label='AUC = {:0.2f}'.format(roc_auc))

    # plt.legend(loc=0)
    # plt.plot([0,1], [0,1], ls='--')
    # plt.ylabel('True Positive Rate')
    # plt.xlabel('False Positive Rate')

    #database connecting ...
    try:
        connection = mysql.connector.connect(host='127.0.0.1',
                                            user = "root",
                                            password = "123456789@0",
                                            db ='plant_sequences')
        if connection.is_connected():
                db_Info = connection.get_server_info()
                print("Connected to MySQL Server version ", db_Info)
                cursor = connection.cursor()
                cursor.execute("select database();")
                record = cursor.fetchone()
                print("You're connected to database: ", record)

    except Error as e:
        log.error("Error while connecting to MySQL", e)

    #processing
    # biopython
    # file with FASTA sequence
    handle_uploaded_file(input_file,'assets/uploads/','input.fasta')

    infile = r'assets/uploads/input.fasta'
    data=pd.read_csv('assets/uploads/output.csv')

    # pattern to search for
    iupac_array =  data['output'].values
    marker = ['o', 'o', 'o', '^', 'v', 'v', 'd', 's', 's', 's', 'd']
    mycursor = connection.cursor()
    sql = "TRUNCATE TABLE plant_promoter_sequence"
    mycursor.execute(sql)
    # i = 0
    for iupac in iupac_array:
        # look through each FASTA sequence in the file
        for seq_record in SeqIO.parse(infile, "fasta"):
            matches = re.findall( iupac, str(seq_record.seq), re.I)
            if matches:
                seq_id = seq_record.id
                sequence = str(seq_record.seq)
                mac = len(matches)
                pos= BMSearch(str(seq_record.seq), iupac)
                insertSql = "INSERT INTO plant_promoter_sequence (seq_id,sequence,matches,match_position,motif_matching) VALUES (%s, %s,%s,%s,%s)"
                mycursor.execute(insertSql,(seq_id,sequence,mac,pos,iupac))
                connection.commit()
    
    # get data
    selectSql = "SELECT seq_id,motif_matching,matches FROM plant_promoter_sequence"
    mycursor.execute(selectSql)
    result = mycursor.fetchall()

    plt.style.use('seaborn-whitegrid')
    plt.figure(figsize=(15,35))
    iupac_array =  data['output'].values
    # for m in iupac
    marker = ['v', '.','s', 'd','o', '^', 'v',  'o',]
    for rows in result:
        plt.plot(rows[2],rows[0],str(random.choice(marker)))
    plt.legend(iupac_array)
    plt.ylabel('Sequence ID\'s')
    plt.xlabel('Matches')
    plt.title('Plant Promoter Sequence (Matches)')
    plt.savefig('assets/img/plant_promoter_sequence_matches.png')


    selectSql = "SELECT seq_id,motif_matching,match_position FROM plant_promoter_sequence"
    mycursor.execute(selectSql)
    result = mycursor.fetchall()

    plt.style.use('seaborn-whitegrid')
    plt.figure(figsize=(15,35))
    iupac_array =  data['output'].values
    # for m in iupac
    marker = ['v', '.','s', 'd','o', '^', 'v',  'o',]
    for rows in result:
        plt.plot(rows[2],rows[0],str(random.choice(marker)))
    plt.legend(iupac_array)
    plt.ylabel('Sequence ID\'s')
    plt.xlabel('Positions')
    plt.title('Plant Promoter Sequence (Match Postions)')
    plt.savefig('assets/img/plant_promoter_sequence_match_positions.png')

    return 0

# Create your views here.
def index(request):
    context = {}
    error1  = ''
    error2  = ''
    error3  = ''
    if (request.method == "POST"):
        # input file for dateset & output file for matching sets
        input_file = request.FILES["input_file"]
        output_file = request.FILES["output_file"]
        # validations
        if not input_file.name.endswith(".fasta"):
            error1 = 'File ('+input_file.name+') is invalid. Please, Choose .fasta file'
        if not output_file.name.endswith(".csv"):
            error2 = 'File ('+output_file.name+') is invalid. Please, Choose .csv file'
        if output_file.name.endswith(".csv"):
            
            handle_uploaded_file(output_file,'assets/uploads/','output.csv')
        if(error1 != "" or error2 != ""):
            context['img1'] = ''
            context['img2'] = ''
            context['error1'] = error1
            context['error2'] = error2
            context['error3'] = error3
            return render(request, 'index.html',context)

        # data  analysis processing start
        dataAnalysis(input_file, output_file)
        img2 = 'assets/img/plant_promoter_sequence_match_positions.png'
        img1 = 'assets/img/plant_promoter_sequence_matches.png'
    else:
        img1 = ""
        img2 = ''
    context['img1'] = img1
    context['img2'] = img2
    context['error1'] = error1
    context['error2'] = error2
    return render(request, 'index.html',context)




