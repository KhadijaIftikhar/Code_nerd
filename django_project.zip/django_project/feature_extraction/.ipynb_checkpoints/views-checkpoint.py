from django.shortcuts import render
from django.http import HttpResponse
import logging as log
# start project libs
from sklearn.model_selection import train_test_split 
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import matplotlib as mpl
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from sklearn.feature_extraction.text import TfidfTransformer 
from sklearn.pipeline import Pipeline
import pandas as pd
import numpy as np
# end project libs

# Create your views here.
def index(request):
    log("log : "+request.method)
    return render(request, 'index.html')


