from django.apps import AppConfig


class FeatureExtractionConfig(AppConfig):
    name = 'feature_extraction'
