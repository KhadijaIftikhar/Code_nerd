$(document).ready( function() {
    /**
     * 
     */
    const input_file  = $('#input_file')
    const output_file = $('#output_file')

    input_file.on('change', function (e){
        let filename = e.target.files[0].name;
        if(filename != ""){
            $('.input_file_label').text(filename)
        }
    })

    output_file.on('change', function (e){
        let filename = e.target.files[0].name;
        if(filename != ""){
            $('.output_file_label').text(filename)
        }
    })
})